mass = float(input('Mass: '))
velocity = float(input('Velocity: '))
print("\nThe object's momentum is", (mass * velocity))