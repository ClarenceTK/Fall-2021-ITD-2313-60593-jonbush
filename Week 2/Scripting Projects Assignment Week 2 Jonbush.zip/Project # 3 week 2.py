n1 = float(input("Enter the number of new videos: "))
n2 = float(input("Enter the number of oldies: "))
print("\nThe total cost is $%.1f"%(n1*3+n2*2))