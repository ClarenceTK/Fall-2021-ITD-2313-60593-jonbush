edge=float(input("Enter the cube's edge: "))
surface_area=6*edge*edge
print("The surface area is "+str(surface_area)+" square")