def convert(number, table):
    """Builds and returns the base two representation of

    number."""

    binary = ""

    for digit in number:

        binary = table[digit] + binary

    return binary
    