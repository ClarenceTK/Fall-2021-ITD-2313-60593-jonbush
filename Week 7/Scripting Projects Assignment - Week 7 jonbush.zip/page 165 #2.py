def main():
   file = input('Please enter the file name: ')
   lines = []
   with open(file, 'r') as f:
       for line in f:
           lines.append(line.strip())
   while True:
       number = int(input('Please input the line number: '))
       if number == 0:
           break
       if number <= len(lines):
           print(lines[number - 1])
       else:
           print('Invalid line number !!')
main()